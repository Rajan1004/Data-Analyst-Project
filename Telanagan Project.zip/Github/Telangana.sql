Select * from dim_districts;
Select * from dim_date;
Select * from fact_stamps;
Select * from fact_transport;
Select * from fact_ts_ipass;
# Below are the top 5 district which have highest document registered 

use resume;
WITH  Document_Registered As (
Select district,
sum(documents_registered_cnt) as Total_Document_Registered
from fact_stamps left join dim_districts on dim_districts.dist_code=fact_stamps.dist_code group by 1 order by 2 DESC)
Select * from (Select *,dense_rank() over(order by Total_Document_Registered DESC) as District_rank from Document_Registered ) as rank_table where District_rank between 1 And 5;
# Below are the top 5 district in term of revenue which have been generated  from document registration in FY 2019-2022
with Document_Revenue as (
Select district,
sum(documents_registered_rev) as Total_Revenue,dense_rank() over(order by sum(documents_registered_rev) DESC) as Dist_Rank
from fact_stamps left join dim_districts on dim_districts.dist_code=fact_stamps.dist_code  group by 1)
Select district,format(Total_Revenue/1000000000,2) as revenue_in_billion from Document_Revenue where Dist_Rank Between 1 And 5;


with revenue_compare as (Select district,
round((Sum(estamps_challans_rev)-sum(documents_registered_rev))/sum(estamps_challans_rev)*100,2) as Compare_revenue_From_challan_VS_Document,Dense_rank() over(order by Sum(estamps_challans_rev)/sum(documents_registered_rev) DESC) as Dist_Rank
from fact_stamps left join dim_districts on dim_districts.dist_code=fact_stamps.dist_code left join dim_date as dd on dd.month=fact_stamps.month
where fiscal_year=2022 group by 1)
Select district, Compare_revenue_From_challan_VS_Document from revenue_compare where Dist_Rank between 1 and 5;
# Now we need to find out the date when the estamps_challan has been issued
Select min(month) from fact_stamps where estamps_challans_cnt>1;
# The date is 2020-12-01
# Now we need to find out the alteration pattern in comparison of e_stamp challan and document registeration count since the implementation of e-Stamp challan has been issued

with Total_registered_count as (Select year(month) as yr,monthname((month)) as mnt, sum(documents_registered_cnt) as Total_document_registered,sum(estamps_challans_cnt) as Total_estamps_challan from fact_stamps where month>='2020-12-01'  group by 1,2)

Select yr ,mnt,round((Total_estamps_challan/Total_document_registered),2)as 'Growth %' from Total_registered_count;

# Now we need to categorized district into three segment based on their stamp registration revenue generation during the fiscal year 2021 to 2022

/* IN My SQL there is no any percentile_count option hence i had first of all create a Common table expression and then figure it out
the rank for all district as per their rev after ward as per the rank i had divided my rank part in 3 segment as per the total rank count
Top 236 will be in high segment from 236 to 472 will be in medium and after ward the remaining one in low level segment*/

 with District_segment as (
Select da.district,estamps_challans_rev  from fact_stamps as f left join dim_date as d on f.month=d.month left join dim_districts as da on da.dist_code =f.dist_code where fiscal_year between 2021 and 2022)

Select district,round(sum(estamps_challans_rev)/10000000,2) as total_rev_in_crore,case When rev_rank<=100 then "High"
when rev_rank>=101 and rev_rank <= 472 then"Medium" else "Low" end as rev_segment  from(Select
 district, 
 estamps_challans_rev,
 dense_rank() over( order by sum(estamps_challans_rev)  DESC) as rev_rank 
 from District_segment group by 1,2) as district_rev group by 1;
 /*  5. Investigate whether there is any correlation between vehicle sales and specific months or seasons
 in different districts. Are there any months or seasons that consistently show higher or lower sales rate, and if yes, 
what could be the driving factors? (Consider Fuel-Type category only) */
with fuel_category as (Select year(f.month) as yr,monthname(f.month) as mnth,month(month) as mn_num,district,fuel_type_petrol,fuel_type_diesel,fuel_type_electric,fuel_type_others 
from fact_transport as f left join dim_districts as d on f.dist_code=d.dist_code) 
Select yr,mnth,(Total_Petrol_Vehicle+Total_diesel_Vehicle+Total_electric_Vehicle+Total_Other_Vehicle) as Total_Vehicle,
dense_rank() over (partition by yr order by (Total_Petrol_Vehicle+Total_diesel_Vehicle+Total_electric_Vehicle+Total_Other_Vehicle) DESC) as sale_rank
 from (

Select mnth,mn_num,yr, sum(fuel_type_petrol) as Total_Petrol_Vehicle,sum(fuel_type_diesel) as Total_diesel_Vehicle,sum(fuel_type_electric)
as Total_electric_Vehicle,sum(fuel_type_others) as Total_Other_Vehicle from fuel_category group by 1,2,3 order by mn_num ) as a;


with fuel_category as (Select year(f.month) as yr,monthname(f.month) as mnth,month(month) as mn_num,district,fuel_type_petrol,fuel_type_diesel,fuel_type_electric,fuel_type_others 
from fact_transport as f left join dim_districts as d on f.dist_code=d.dist_code) 
Select * from  (Select mnth,district,(Total_Petrol_Vehicle+Total_diesel_Vehicle+Total_electric_Vehicle+Total_Other_Vehicle) as Total_Vehicle,
dense_rank() over (partition by mnth,district order by (Total_Petrol_Vehicle+Total_diesel_Vehicle+Total_electric_Vehicle+Total_Other_Vehicle) DESC) as sale_rank
 from (

Select mnth,mn_num,yr, district, sum(fuel_type_petrol) as Total_Petrol_Vehicle,sum(fuel_type_diesel) as Total_diesel_Vehicle,sum(fuel_type_electric)
as Total_electric_Vehicle,sum(fuel_type_others) as Total_Other_Vehicle from fuel_category group by 1,2,3,4 order by mn_num ) as a order by mn_num) b where sale_rank=1;
use resume;

Select sector,round(sum(`investment in cr`),2) as Total_invest,dense_rank() over(  order by sum(`investment in cr`) DESC) as sector_rank from fact_ts_ipass group by sector;
/* 6. How does the distribution of vehicles vary by vehicle class (MotorCycle, MotorCar, AutoRickshaw, Agriculture) across different 
districts? Are there any districts with a predominant preference for a specific vehicle class? Consider FY 2022 for analysis.*/
use resume;
with vehicle as (
Select district, sum(vehicleClass_MotorCycle) as Motorcycle,sum(vehicleClass_AutoRickshaw) as Autorickshaw,
sum(vehicleClass_MotorCar) as MotorCar,sum(vehicleClass_Agriculture) as Agriculture
from fact_transport as f left join dim_districts as d on d.dist_code=f.dist_code where month between '2021-04-01' And '2022-03-31' group by 1 order by 2 DESC)

Select * from (Select district,rank() over (order by Motorcycle DESC ) as Motorcycle_rank,rank() over (order by Autorickshaw DESC ) as Autorickshaw_rank,
rank() over (order by MotorCar DESC ) as Motor_car_rank, rank() over (order by Agriculture DESC ) as Agriculture_rank from vehicle) as a where Motorcycle_rank Between 1 and 3 or Autorickshaw_rank Between 1 and 3 or  Motor_car_rank Between 1 and 3 or Agriculture_rank Between 1 and 3 order by 2,3,4,5 DESC;

/* List down the top 3 and bottom 3 districts that have shown the highest and lowest vehicle 
sales growth during FY 2022 compared to FY  2021? (Consider and compare categories: Petrol, Diesel and Electric) */

Create Temporary table Sale_growth
with sale_growth as (
Select fiscal_year,district ,sum(fuel_type_petrol) as petrol,sum(fuel_type_diesel) as diesel,
sum(fuel_type_electric) as electric,(sum(fuel_type_petrol)+sum(fuel_type_diesel)+ sum(fuel_type_electric) )as Total_Vehicle
from fact_transport as f left join dim_districts as d on f.dist_code=d.dist_code 
left join dim_date as dd on dd.month=f.month where fiscal_year between 2021 And 2022 group by 1 ,2 ) 

Select s1.district,round((s2.petrol-s1.petrol)/s1.petrol * 100,2) as Petrol_growth_per,
round((s2.diesel-s1.diesel)/s1.diesel * 100,2) as Diesel_growth_per,
round((s2.electric-s1.electric)/s1.electric * 100,2) as Electric_growth_per,
round((s2.Total_Vehicle-s1.Total_Vehicle)/s1.Total_Vehicle * 100,2) as Total_Vehicle_growth_per
from sale_growth as s1 join sale_growth as s2 on s1.district=s2.district where s1.fiscal_year=2021 and s2.fiscal_year=2022;

# Top 3 and bottom 3 District in Petrol vehiclesales growth during FY 2022 compared to FY 2021
Select district,petrol_growth_per from (
Select district, Petrol_growth_per,
rank()over( order by Petrol_growth_per DESC) Top_rank,
rank()over( order by Petrol_growth_per ASC) Bottom_rank from Sale_growth) as a where Top_rank <=3 or Bottom_rank<=3 order by Top_rank;
# Top 3 and bottom 3 District in Diesel vehiclesales growth during FY 2022 compared to FY 2021
Select district,Diesel_growth_per from (
Select district, Diesel_growth_per,
rank()over( order by Diesel_growth_per DESC) Top_rank,
rank()over( order by Diesel_growth_per ASC) Bottom_rank from Sale_growth) as a where Top_rank <=3 or Bottom_rank<=3 order by Top_rank;

#Top 3 and bottom 3 District in Electric vehicle sales growth during FY 2022 compared to FY 2021
Select district,Electric_growth_per from (
Select district, Electric_growth_per,
rank()over( order by Electric_growth_per DESC) Top_rank,
rank()over( order by Electric_growth_per ASC) Bottom_rank from Sale_growth) as a where Top_rank <=3 or Bottom_rank<=3 order by Top_rank;

# Top 3 and bottom 3 District in Total  vehicle sales growth during FY 2022 compared to FY 2021
Select district,Total_Vehicle_growth_per from (
Select district, Total_Vehicle_growth_per,
rank()over( order by Total_Vehicle_growth_per DESC) Top_rank,
rank()over( order by Total_Vehicle_growth_per ASC) Bottom_rank from Sale_growth) as a where Top_rank <=3 or Bottom_rank<=3 order by Top_rank;

/* 8. List down the top 5 sectors that have witnessed the most significant investments in FY 2022.*/

Select  sector,round(sum(`investment in cr`),2) as TOtal_Investment 
from fact_ts_ipass as f left join dim_date as d on f.month=d.month
where fiscal_year=2022
group by 1 order by 2 DESC  limit 5;

Select sum(`investment in cr`),sector from fact_ts_ipass group by 2 order by 1 DESC ;



/* 9.  List down the top 3 districts that have attracted the most significant  sector investments during FY 2019 to 2022? 
What factors could have led to the substantial investments in these particular districts?*/
with investment_sub as(
select district,sector,
round(sum(`investment in cr`),2) as Total_Investment_In_CR 
from fact_ts_ipass as f  
left join dim_districts as d on d.dist_code=f.dist_code  
where month between '2018-03-31' And '2022-04-01' group by 1,2 order by 2 DESC )

Select district,sector from (Select *,dense_rank() over(partition by district order by Total_Investment_In_CR DESC) as ranking
 from investment_sub) as a 
where ranking between 1 And 3;


Use resume;
/* Are there any particular sectors that have shown substantial investment in multiple districts between FY 2021 and 2022?*/
Select  f.sector, count(Distinct district) as total_district,round(sum(f.`investment in cr`),0) as total_investment 
 from fact_ts_ipass as f left join dim_districts  as d on f.dist_code=d.dist_code left join dim_date on dim_date.month=f.month where fiscal_year in (2021,2022) group by 1 order by 2 DESC;
 
/* Total Stamp revenue in each year*/
 Select  year(d.month) as yr, round((sum(f.documents_registered_rev)+sum(f.estamps_challans_rev))
 /1000000000 ,2) as Total_revenue from dim_date as d left join 
 fact_stamps as f on f.month=d.month  group by 1;
 
/* Is there any relationship between district investments, vehicles sales and stamps revenue within the same district between FY 2021
 and 2022  */
 
 Select district,sum(`investment in cr`) as Total_Investment, 
 sum((vehicleClass_MotorCycle+vehicleClass_MotorCar+vehicleClass_AutoRickshaw+vehicleClass_Agriculture+vehicleClass_others)) as Total_Vehicle,
 sum((documents_registered_rev+estamps_challans_rev)) as Total_rev from dim_districts left join fact_stamps on dim_districts.dist_code=
 fact_stamps.dist_code left join fact_transport on dim_districts.dist_code=fact_stamps.dist_code left join fact_ts_ipass on
 fact_ts_ipass.dist_code=dim_districts.dist_code left join dim_date on dim_date.month=fact_stamps.month where fiscal_year between 2021 and 2022 group  by 1;
 
 
/* Can we identify any seasonal patterns or cyclicality in the investment trends for specific sectors? 
Do certain sectors experience higher investments during particular months*/

with seasons as (
Select case when Mmm in('Feb','Mar','Apr') then 'Autum' when Mmm In('Jul','May','Jun') then 'Summer' when Mmm in ('Oct','Aug','Sep') then 'Monsoon'
when Mmm In ('Nov','Dec','Jan') then 'Winter' end as Season,sector,round(sum(`investment in cr`),2) as Total_Investment
 from dim_date left join fact_ts_ipass on dim_date.month=fact_ts_ipass.month group by 1,2)
 
Select Season,sector from (Select Season,sector,Total_Investment,dense_rank() over(partition by Season order by Total_Investment DESC) as ranking from seasons) as a  where ranking Between 1 and 3;



























 





